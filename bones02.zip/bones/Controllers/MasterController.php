<?php

namespace Controllers;

class MasterController {
    /**
     *
     * @var \View
     */
//    protected $view;
//    protected $controller;
//
//
//    public function __construct(\View $view, $controller) {
//        
//        $this->view = $view;
//        
//        $this->controller = $controller;
//        
//        $this->onLoad();
//    }
    
    public function view() {
       $url = explode( '/', trim($_SERVER["REQUEST_URI"], '/') );
        
       $controller = 'home';
       $action = 'index';
       
        $view = 'Views' . DIRECTORY_SEPARATOR . $controller . DIRECTORY_SEPARATOR . $action . '.php';
        require_once $view;
   
    }
    
    public function onLoad() {
        
    }
        
    public function redirectViews($action){
        $url = explode('/', $_SERVER['REQUEST_URI']);
       
        $var = $action;
        header('Location: ' . $var);
        exit;
    }
    
    public function redirectControllers($controller, $action){
        
        $url = explode('/', trim($_SERVER['REQUEST_URI'], '/'));
        $url = DIRECTORY_SEPARATOR . $url[0];
        $url .= DIRECTORY_SEPARATOR . $controller . DIRECTORY_SEPARATOR . $action;
        
        header("Location: " . $url);
        exit;
    }
}
