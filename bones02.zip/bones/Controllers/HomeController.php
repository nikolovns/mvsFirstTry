<?php

namespace Controllers;

class HomeController extends MasterController {

    public function index() {

        $page = \Repository\Page::createInstance()
                ->selectAllPages();

        $this->slug = $page;

        $this->view();
    }

}
