
</div>
<footer><h4>This is my footer for all pages</h4></footer>
</body>
</html>

