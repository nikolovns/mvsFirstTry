<?php require_once 'templateHTML/header.php'; ?>

<ul>

    <?php $vars = ( $this->slug ); ?>
    
    <?php foreach ($vars as $key => $value): ?>
        <li>
            <?php echo $value->getTitle(); ?>
        </li>
    <?php endforeach; ?>
        
</ul>

<?php require_once 'templateHTML/footer.php'; ?>