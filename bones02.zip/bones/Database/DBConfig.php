<?php

namespace Database;

class DBConfig {
    
    const DB_HOST = 'localhost';
    const DB_NAME = 'regular';
    const DB_USER = 'root';
    const DB_PASS = '';
    
}
